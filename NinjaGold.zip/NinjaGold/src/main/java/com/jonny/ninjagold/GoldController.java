package com.jonny.ninjagold;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GoldController {
	@RequestMapping("/")
	public String home(HttpSession session) {
		if(session.getAttribute("gold") == null) {
			session.setAttribute("gold", 0);
			return "index.jsp";			
		}
		return "index.jsp";
	}
	
	@RequestMapping(value="/results", method=RequestMethod.POST)
	public String results(HttpSession session, @RequestParam(value="whichform") String form) {
		Integer count = (Integer) session.getAttribute("gold");
		Random rand = new Random();
		int gold = 0;
		String activity = "";
		String timeStamp = new SimpleDateFormat("MMMM.dd.yy hh.mm").format(new Date());
		if(form.equals("farm")) {
			gold = rand.nextInt(20-10)+10;
			count += gold;
			activity = "You enterered the farm and earned " + gold + " gold. " + timeStamp;
		}
		if(form.equals("cave")) {
			gold = rand.nextInt(10-5)+5;
			count += gold;
			activity = "You enterered the cave and earned " + gold + " gold. " + timeStamp;
		}
		if(form.equals("house")) {
			gold = rand.nextInt(5-2)+2;
			count += gold;
			activity = "You enterered the house and earned " + gold + " gold. " + timeStamp;
		}
		if(form.equals("casino")) {
			gold = rand.nextInt(50);
			int operator = rand.nextInt(2);
			System.out.println(operator);
			if(operator == 0) {
				count += gold;
				activity = "You enterered the casino and earned " + gold + " gold. " + timeStamp;
			}
			else if(operator == 1) {
				count -= gold;
				activity = "You enterered the casino and lost " + gold + " gold. " + timeStamp;
			}
		}
		session.setAttribute("activity", activity);
		session.setAttribute("gold", count);
		return "redirect:/";
	}
}
