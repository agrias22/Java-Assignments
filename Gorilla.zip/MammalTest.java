public class MammalTest {
    public static void main(String[] args){
        Gorilla harambe = new Gorilla();
        harambe.displayEngergy();
        harambe.throwSomething();
        harambe.throwSomething();
        harambe.throwSomething();
        harambe.eatBananas();
        harambe.eatBananas();
        harambe.climb();
        harambe.climb();
        harambe.displayEngergy();
    }    
}
