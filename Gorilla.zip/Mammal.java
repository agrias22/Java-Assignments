class Mammal {
    public int energyLevel = 100;
    
    public void displayEngergy(){
        System.out.println("Engergy Level is: " + energyLevel);
    }
}
