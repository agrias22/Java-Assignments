
class Gorilla extends Mammal{
    public void throwSomething(){
        energyLevel -= 10;
        System.out.println("Gorilla has thrown a bannana");
    }
    public void eatBananas(){
        energyLevel += 10;
        System.out.println("The Gorilla is Satisfied");
    }
    public void climb(){
        energyLevel -= 10;
        System.out.println("This Gorilla has climbed a tree");
    }
}
