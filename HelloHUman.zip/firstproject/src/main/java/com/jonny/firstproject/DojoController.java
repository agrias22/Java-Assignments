package com.jonny.firstproject;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
@RestController
public class DojoController {
	@RequestMapping("/m/{first}")
	public String showFirst(@PathVariable("first") String first) {
		if(first.equals("dojo")) {
			return "The dojo is awesome";
		}
		else if(first.equals("burbank-dojo")) {
			return "Burbank Dojo is located in Southern California";
		}
		else if(first.equals("san-jose")){
			return "SJ dojo is the headquarters";
		}
		else {
			return "There was an error";
		}
	}
	
}
