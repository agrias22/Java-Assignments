package com.jonny.firstproject;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@RestController
public class HelloUser {
	@RequestMapping("/user")
	public String index(@RequestParam(value="q", required =false) String checkUser) {
		if(checkUser == null) {
			return "Hello Human";
		}
		else {
			return "Hello " + checkUser;		}
	}
	@RequestMapping("/user")
	public String greeting() {
		return "Welcome to Spring Suite";
	}
}
