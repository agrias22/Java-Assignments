
public class Human {
    private int strength = 3;
    private int stealth = 3;
    private int intelligence = 3;
    private int health = 100;

    public void attack(Human Human){
        Human.health -= this.strength;
    }
    public void displayHealth(){
        System.out.println("Health is: " + this.health);
    }
}
