
public class HumanTest {
    public static void main(String[] args){
        Human joey = new Human();
        Human teddy = new Human();
        teddy.displayHealth();
        joey.attack(teddy);
        teddy.displayHealth();
    }
}
