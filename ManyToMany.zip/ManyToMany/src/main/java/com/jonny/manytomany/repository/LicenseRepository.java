package com.jonny.manytomany.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jonny.manytomany.models.License;

//...
@Repository
public interface LicenseRepository extends CrudRepository<License, Long>{
 List<License> findAll();
 List<License>stateContaining(String search);
 Long countByidContaining(String search);
 Long deleteByidStartingWith(String search);
}


