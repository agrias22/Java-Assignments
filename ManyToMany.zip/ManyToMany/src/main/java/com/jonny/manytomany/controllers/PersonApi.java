package com.jonny.manytomany.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;


import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jonny.manytomany.models.Person;
import com.jonny.manytomany.services.PersonService;

//..

@RestController
public class PersonApi {
 private final PersonService personService;
 public PersonApi(PersonService personService){
     this.personService = personService;
 }
 @RequestMapping("/api/persons")
 public List<Person> index() {
     return personService.allPersons();
 }
 
 @RequestMapping(value="/api/persons", method=RequestMethod.POST)
 public Person create(@RequestParam(value="firstName") String firstName, 
		 				@RequestParam(value="lastName") String lastName, HttpSession session) {
     Person person = new Person(firstName, lastName);
     
     return personService.createPerson(person);
 }
 
 @RequestMapping("/api/person/{id}")
 public Person show(@PathVariable("id") Long id) {
     Person person = personService.findPerson(id);
     return person;
 }
 
 @RequestMapping(value="/api/person/{id}", method=RequestMethod.DELETE)
 public void destroy(@PathVariable("id") Long id) {
     personService.deletePerson(id);
 }
}

