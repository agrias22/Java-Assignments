package com.jonny.manytomany.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jonny.manytomany.models.Person;


@Repository
public interface PersonRepository extends CrudRepository<Person, Long>{
 List<Person> findAll();
 List<Person> findByfirstNameContaining(String search);
 Long countByfirstNameContaining(String search);
 Long deleteByidStartingWith(String search);
}

