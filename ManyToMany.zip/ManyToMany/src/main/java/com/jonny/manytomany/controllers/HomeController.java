package com.jonny.manytomany.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jonny.manytomany.models.License;
import com.jonny.manytomany.models.Person;
import com.jonny.manytomany.services.LicenseService;
import com.jonny.manytomany.services.PersonService;

@Controller
public class HomeController {
 // other methods removed for brevity
    private final PersonService personService;
private LicenseService licenseService;
    
    public HomeController(PersonService personService, LicenseService licenseService) {
        this.personService = personService;
        this.licenseService = licenseService;
    }
 @RequestMapping("/persons/new")
 public String newPerson(@ModelAttribute("person") Person person) {
     return "newPerson.jsp";
 }
 
 @RequestMapping(value="/persons", method=RequestMethod.POST)
 public String create(@Valid @ModelAttribute("person") Person person, BindingResult result) {
     if (result.hasErrors()) {
         return "newPerson.jsp";
     } else {
         personService.createPerson(person);
         return "redirect:/license/new";
     }
 }
 
 @RequestMapping("/license/new")
 public String newLicense(@ModelAttribute("license") License license, Model model) {
     model.addAttribute("people", personService.allPersons());
	 return "newLicense.jsp";
 }
 
 @RequestMapping(value="/license/new", method=RequestMethod.POST)
 public String create(@Valid @ModelAttribute("license") License license, BindingResult result) {
     if (result.hasErrors()) {
         return "newLicense.jsp";
     } else {
         licenseService.createLicense(license);
         return "redirect:/index";
     }
 }
 @RequestMapping("/index")
 public String index(Model model) {
     List<License> licenses = licenseService.allLicenses();
     model.addAttribute("license", licenses);
     return "index.jsp";
 }
 @RequestMapping("show/{id}")
 public String showLicense(@PathVariable("id") Long id, Model models) {
	 License license = licenseService.findLicense(id);
	 models.addAttribute("soloLice", license);
	 return "show.jsp";
 }
}
