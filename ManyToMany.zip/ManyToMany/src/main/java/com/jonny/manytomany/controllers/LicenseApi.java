package com.jonny.manytomany.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jonny.manytomany.models.License;
import com.jonny.manytomany.models.Person;
import com.jonny.manytomany.services.LicenseService;
import com.jonny.manytomany.services.PersonService;

@RestController
public class LicenseApi {
 private final LicenseService licenseService;
private final PersonService personService;
 public LicenseApi(LicenseService licenseService, PersonService personService){
     this.licenseService = licenseService;
     this.personService = personService;
 }
 
 @RequestMapping("/api/licenses")
 public List<License> index() {
     return licenseService.allLicenses();
 }
 
 @RequestMapping(value="/api/licenses", method=RequestMethod.POST)
 public License create(@RequestParam(value="personID") Long personID,
		 				@RequestParam(value="state") String state, 
		 				@RequestParam(value="experationDate") Date experationDate) {
	 Person person = personService.findPerson(personID);
     License license = new License(person, experationDate, state);
     return licenseService.createLicense(license);
     
     
 }
 
 @RequestMapping("/api/license/{id}")
 public License show(@PathVariable("id") Long id) {
     License license = licenseService.findLicense(id);
     return license;
 }
}
