package com.jonny.manytomany.services;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.jonny.manytomany.models.License;
import com.jonny.manytomany.repository.LicenseRepository;
@Service
public class LicenseService {
 // adding the book repository as a dependency
 private final LicenseRepository licenseRepository;
 
 public LicenseService(LicenseRepository licenseRepository) {
     this.licenseRepository = licenseRepository;
 }
 // returns all the books
 public List<License> allLicenses() {
     return licenseRepository.findAll();
 }
 // creates a book
 public License createLicense(License a) {
     return licenseRepository.save(a);
 }
 // retrieves a book
 public License findLicense(Long id) {
     Optional<License> optionalLicense = licenseRepository.findById(id);
     if(optionalLicense.isPresent()) {
         return optionalLicense.get();
     } else {
         return null;
     }
 }
}

