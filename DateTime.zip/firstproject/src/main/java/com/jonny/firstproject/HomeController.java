package com.jonny.firstproject;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
@Controller
public class HomeController {

	@RequestMapping("")
	public String home(Model model) {
		model.addAttribute("dojoName", "Portland");
		return "index.jsp";
	}
	@RequestMapping("/date")
	public String datePage(Model model) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMMMM-dd-yyyy");
		String date = simpleDateFormat.format(new Date());
		model.addAttribute("dayOfWeek", date);
		return "date.jsp";
	}
	@RequestMapping("/time")
	public String timePage(Model model) {
		SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("hh:mm");
		String time = simpleTimeFormat.format(new Date());
		model.addAttribute("timeOfDay", time);
		return "time.jsp";
	}
}
