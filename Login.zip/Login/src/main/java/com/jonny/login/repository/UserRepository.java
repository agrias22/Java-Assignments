package com.jonny.login.repository;

import org.springframework.data.repository.CrudRepository;

import com.jonny.login.models.User;

public interface UserRepository extends CrudRepository<User, Long>{
	User findByEmail(String Email);
}
