package com.jonny.firstproject;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Date;

import javax.servlet.http.HttpSession;

import java.text.SimpleDateFormat;
@Controller
public class HomeController {

	@RequestMapping("")
	public String home(Model model) {
		model.addAttribute("dojoName", "Portland");
		return "index.jsp";
	}
	@RequestMapping("/date")
	public String datePage(Model model) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMMMM-dd-yyyy");
		String date = simpleDateFormat.format(new Date());
		model.addAttribute("dayOfWeek", date);
		return "date.jsp";
	}
	@RequestMapping("/time")
	public String timePage(Model model) {
		SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("hh:mm");
		String time = simpleTimeFormat.format(new Date());
		model.addAttribute("timeOfDay", time);
		return "time.jsp";
	}
	@RequestMapping("/server")
	public String server(HttpSession session) {
		 session.setAttribute("count", 0);
	     Integer count = (Integer) session.getAttribute("count");
	     count++;
        return "counter.jsp";
	}
	@RequestMapping("/secret")
	public String secret() {
		return "dojo.jsp";
	}
	@RequestMapping(value="/results", method=RequestMethod.POST)
	public String result(@RequestParam(value="guess") String userGuess) {
		if(userGuess.equals("Bushido") == false) {
			return "redirect:/createError";
		}
		else {
			return "results.jsp";
		}
	}
    @RequestMapping("/createError")
    public String flashMessages(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", "You must train harder!");
        return "redirect:/secret";
    }
    
    @RequestMapping("/survey")
    public String dojoSurvey() {
    	return "survey.jsp";
    }
    @RequestMapping("/surveyresults")
    public String surveyResults(@RequestParam(value="userName") String userName, @RequestParam(value="location") String location, @RequestParam(value="language") String language, @RequestParam(value="comment") String comment, HttpSession sesh ) {
    	sesh.setAttribute("username", userName);
    	sesh.setAttribute("location", location);
    	sesh.setAttribute("language", language);
    	sesh.setAttribute("comment", comment);
    	return "surveyresults.jsp";
    }
}
